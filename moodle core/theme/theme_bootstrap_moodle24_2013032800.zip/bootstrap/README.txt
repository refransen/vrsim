This theme is based on the Bootstrap CSS framework, version 2.3

NOTE FOR USERS UPGRADING FROM THE OLD THEME:
Read the changelog. using this version will remove your bootstrap theme settings

Changelog:
- CSS compiled with less. Learn less to modify this theme, don't worry that's easy. Just read
http://www.lesscss.org. Further instructions in less/README
- This version uses a 2-1-3 layout. In raw HTML this means content goes first. Good for Google indexing & screen reader
- This version uses YUI. The YUI libs for bootstrap are a work in progress. If you want to use jQuery download and use the moodle_25_jquery branch on github.

http://getbootstrap.com

This is a GPL theme that is available on GitHub:

https://github.com/bmbrands/theme_bootstrap

Feel free to modify / improve / share

For more information on this theme go to:
https://github.com/bmbrands/theme_bootstrap/wiki

This theme has been created with the help of:
Stuart Lamour, Mark Aberdour, Paul Hibbitts, Mary Evans

Authors: Bas Brands, David Scotson
Contact: bmbrands@gmail.com
Website: www.basbrands.nl
