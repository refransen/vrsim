<?php


defined('MOODLE_INTERNAL') || die;

if ($ADMIN->fulltree) {
	
// Fullscreen Toggle
$name = 'theme_VRSim/width';
$title = get_string('width','theme_VRSim');
$description = get_string('widthdesc', 'theme_VRSim');
$default = 960;
$choices = array(960=>get_string('fixedwidth','theme_VRSim'), 97=>get_string('variablewidth','theme_VRSim'));
$setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
$settings->add($setting);

// Gap Toggle
$name = 'theme_VRSim/gap';
$title = get_string('gap','theme_VRSim');
$description = get_string('gapdesc', 'theme_VRSim');
$default = 70;
$choices = array(70=>get_string('yes',''), 45=>get_string('no',''));
$setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
$settings->add($setting);

// Hide Menu
$name = 'theme_VRSim/hidemenu';
$title = get_string('hidemenu','theme_VRSim');
$description = get_string('hidemenudesc', 'theme_VRSim');
$default = 1;
$choices = array(1=>get_string('yes',''), 0=>get_string('no',''));
$setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
$settings->add($setting);

// Graphic Wrap (Background Image)
$name = 'theme_VRSim/backimage';
$title=get_string('backimage','theme_VRSim');
$description = get_string('backimagedesc', 'theme_VRSim');
$default = 'VRSim/pix/graphics/default.jpg';
$setting = new admin_setting_configtext($name, $title, $description, 'VRSim/pix/graphics/default.jpg', PARAM_URL);
$settings->add($setting);

// Graphic Wrap (Background Position)
$name = 'theme_VRSim/backposition';
$title = get_string('backposition','theme_VRSim');
$description = get_string('backpositiondesc', 'theme_VRSim');
$default = 'no-repeat';
$choices = array('no-repeat'=>get_string('backpositioncentred','theme_VRSim'), 'no-repeat fixed'=>get_string('backpositionfixed','theme_VRSim'), 'repeat'=>get_string('backpositiontiled','theme_VRSim'), 'repeat-x'=>get_string('backpositionrepeat','theme_VRSim'));
$setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
$settings->add($setting);

// Menu background colour setting
$name = 'theme_VRSim/backcolor';
$title = get_string('backcolor','theme_VRSim');
$description = get_string('backcolordesc', 'theme_VRSim');
$default = '#ffffff';
$previewconfig = NULL;
$setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
$settings->add($setting);

// Logo file setting
$name = 'theme_VRSim/logo';
$title = get_string('logo','theme_VRSim');
$description = get_string('logodesc', 'theme_VRSim');
$setting = new admin_setting_configtext($name, $title, $description, '', PARAM_URL);
$settings->add($setting);

// Menu background colour setting
$name = 'theme_VRSim/menubackcolor';
$title = get_string('menubackcolor','theme_VRSim');
$description = get_string('menubackcolordesc', 'theme_VRSim');
$default = '#333333';
$previewconfig = NULL;
$setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
$settings->add($setting);

// Menu hover background colour setting
$name = 'theme_VRSim/menuhovercolor';
$title = get_string('menuhovercolor','theme_VRSim');
$description = get_string('menuhovercolordesc', 'theme_VRSim');
$default = '#f42941';
$previewconfig = NULL;
$setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
$settings->add($setting);

// Profilebar custom block title setting

$name = 'theme_VRSim/profilebarcustomtitle';
$title = get_string('profilebarcustomtitle','theme_VRSim');
$description = get_string('profilebarcustomtitledesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);

// Profilebar custom block setting

$name = 'theme_VRSim/profilebarcustom';
$title = get_string('profilebarcustom','theme_VRSim');
$description = get_string('profilebarcustomdesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_confightmleditor($name, $title, $description, $default);
$settings->add($setting);
	
// Email url setting

$name = 'theme_VRSim/emailurl';
$title = get_string('emailurl','theme_VRSim');
$description = get_string('emailurldesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);

// Title Date setting

$name = 'theme_VRSim/titledate';
$title = get_string('titledate','theme_VRSim');
$description = get_string('titledatedesc', 'theme_VRSim');
$default = 1;
$choices = array(1=>get_string('yes',''), 0=>get_string('no',''));
$setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
$settings->add($setting);

// Copyright setting

$name = 'theme_VRSim/copyright';
$title = get_string('copyright','theme_VRSim');
$description = get_string('copyrightdesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);

// CEOP
$name = 'theme_VRSim/ceop';
$title = get_string('ceop','theme_VRSim');
$description = get_string('ceopdesc', 'theme_VRSim');
$default = '';
$choices = array(''=>get_string('ceopnone','theme_VRSim'), 'http://www.thinkuknow.org.au/site/report.asp'=>get_string('ceopaus','theme_VRSim'), 'http://www.ceop.police.uk/report-abuse/'=>get_string('ceopuk','theme_VRSim'));
$setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
$settings->add($setting);

// Disclaimer setting
$name = 'theme_VRSim/disclaimer';
$title = get_string('disclaimer','theme_VRSim');
$description = get_string('disclaimerdesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_confightmleditor($name, $title, $description, $default);
$settings->add($setting);

// Facebook url setting

$name = 'theme_VRSim/facebook';
$title = get_string('facebook','theme_VRSim');
$description = get_string('facebookdesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);

// Twitter url setting

$name = 'theme_VRSim/twitter';
$title = get_string('twitter','theme_VRSim');
$description = get_string('twitterdesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);

// Google+ url setting

$name = 'theme_VRSim/googleplus';
$title = get_string('googleplus','theme_VRSim');
$description = get_string('googleplusdesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);

// Flickr url setting

$name = 'theme_VRSim/flickr';
$title = get_string('flickr','theme_VRSim');
$description = get_string('flickrdesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);

// Picasa url setting

$name = 'theme_VRSim/picasa';
$title = get_string('picasa','theme_VRSim');
$description = get_string('picasadesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);

// Tumblr url setting

$name = 'theme_VRSim/tumblr';
$title = get_string('tumblr','theme_VRSim');
$description = get_string('tumblrdesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);

// Instagram url setting

$name = 'theme_VRSim/instagram';
$title = get_string('instagram','theme_VRSim');
$description = get_string('instagramdesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);

// Blogger url setting

$name = 'theme_VRSim/blogger';
$title = get_string('blogger','theme_VRSim');
$description = get_string('bloggerdesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);

// LinkedIn url setting

$name = 'theme_VRSim/linkedin';
$title = get_string('linkedin','theme_VRSim');
$description = get_string('linkedindesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);

// YouTube url setting

$name = 'theme_VRSim/youtube';
$title = get_string('youtube','theme_VRSim');
$description = get_string('youtubedesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);

// Vimeo url setting

$name = 'theme_VRSim/vimeo';
$title = get_string('vimeo','theme_VRSim');
$description = get_string('vimeodesc', 'theme_VRSim');
$default = '';
$setting = new admin_setting_configtext($name, $title, $description, $default);
$settings->add($setting);


}