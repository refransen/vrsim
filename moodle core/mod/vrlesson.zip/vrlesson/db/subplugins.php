<?php

$subplugins = array('datafield'  => 'mod/vrlesson/field',
                    'datapreset' => 'mod/vrlesson/preset');